import sys
import openai
import key

openai.api_key = key.mykey

def print_partial_or_complete_response(question):
    completion = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": question}]
    )
    response = completion['choices'][0]['message']['content']
    finish_reason = completion['choices'][0]['finish_reason']

    if finish_reason == "stop":
        # 完整的回答
        encoded_data = response.encode('utf-8',errors='ignore')
        sys.stdout.buffer.write(encoded_data)
        sys.stdout.buffer.flush()
    else:
        # 部分回答
        encoded_data = response.encode('utf-8',errors='ignore')
        sys.stdout.buffer.write(encoded_data)
        sys.stdout.buffer.flush()


# 从标准输入读取数据
data = sys.stdin.buffer.readline().decode('utf-8')
print_partial_or_complete_response(data)